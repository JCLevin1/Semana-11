import javax.swing.*;
import java.awt.*;

public class Prueba extends JFrame {
    public Prueba() {
        initUI();
    }

    private void initUI() {
        JButton boton = new JButton("Presionar");
        boton.addActionListener(e -> JOptionPane.showMessageDialog(this, "Botón pulsado"));

        setLayout(new FlowLayout());
        add(boton);

        setTitle("Formulario con botón");
        setSize(300, 100);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Prueba().setVisible(true));
    }
}